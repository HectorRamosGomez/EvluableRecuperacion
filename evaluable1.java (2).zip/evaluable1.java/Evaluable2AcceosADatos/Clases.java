import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.*;

public class Clases {
    abstract class PersistentSystem {

    }

    class FileSystem extends PersistentSystem {

        public static void CreateVideogame(int idUser) {
            Scanner sc = new Scanner(System.in);
            String ruta = "C:\\" + idUser + "\\VideoGames.csv";

            try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
                
                bw.write("identificador,título,género,compañía,fecha de lanzamiento,horas jugadas,indicador de favorito");
                bw.newLine();

                boolean seguir = true;
                while (seguir) {
                    System.out.println("Introduce los datos del videojuego:");

                    System.out.print("Identificador: ");
                    String id = sc.nextLine();

                    System.out.print("Título: ");
                    String titulo = sc.nextLine();

                    System.out.print("Género: ");
                    String genero = sc.nextLine();

                    System.out.print("Compañía: ");
                    String compania = sc.nextLine();

                    System.out.print("Fecha de lanzamiento: ");
                    String fecha = sc.nextLine();

                    System.out.print("Horas jugadas: ");
                    String horas = sc.nextLine();

                    System.out.print("Indicador de favorito (true/false): ");
                    String favorito = sc.nextLine();

                    String fila = String.join(",", id, titulo, genero, compania, fecha, horas, favorito);
                    bw.write(fila);
                    bw.newLine();

                    System.out.println("¿Quieres añadir otro videojuego? (s/n): ");
                    String resp = sc.nextLine();
                    if (!resp.equalsIgnoreCase("s")) {
                        seguir = false;
                    }
                }

                System.out.println("Archivo CSV creado y completado correctamente");

            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        public static void EditFile(int idUser) {
            Scanner sc = new Scanner(System.in);
            String ruta = "C:\\" + idUser + "\\VideoGames.csv";

            List<String[]> datos = new ArrayList<>();
            String header = null;

            try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
                String linea;
                if ((linea = br.readLine()) != null) {
                    header = linea;
                }
                while ((linea = br.readLine()) != null) {
                    datos.add(linea.split(",", -1));
                }
            } catch (IOException e) {
                System.out.println("Error al leer el archivo del usuario " + idUser + ": " + e.getMessage());
                return;
            }

            System.out.print("Introduce el ID del videojuego a editar: ");
            String idBuscado = sc.nextLine().trim();

            boolean encontrado = false;
            for (String[] fila : datos) {
                if (fila.length == 0) continue;
                if (fila[0].equals(idBuscado)) {
                    encontrado = true;
                    System.out.println("Videojuego encontrado: " + Arrays.toString(fila));

                    boolean seguirEditando = true;
                    while (seguirEditando) {
                        System.out.println("\n¿Qué columna quieres editar?");
                        System.out.println("1. Título");
                        System.out.println("2. Género");
                        System.out.println("3. Compañía");
                        System.out.println("4. Fecha de lanzamiento");
                        System.out.println("5. Horas jugadas");
                        System.out.println("6. Indicador de favorito");
                        System.out.println("7. Salir de edición");
                        System.out.print("> ");

                        String opcionStr = sc.nextLine().trim();
                        int opcion;
                        try {
                            opcion = Integer.parseInt(opcionStr);
                        } catch (NumberFormatException ex) {
                            System.out.println("Opción inválida, introduce un número entre 1 y 7.");
                            continue;
                        }

                        switch (opcion) {
                            case 1:
                                System.out.print("Nuevo título: ");
                                fila[1] = sc.nextLine();
                                break;
                            case 2:
                                System.out.print("Nuevo género: ");
                                fila[2] = sc.nextLine();
                                break;
                            case 3:
                                System.out.print("Nueva compañía: ");
                                fila[3] = sc.nextLine();
                                break;
                            case 4:
                                System.out.print("Nueva fecha de lanzamiento: ");
                                fila[4] = sc.nextLine();
                                break;
                            case 5:
                                System.out.print("Nuevas horas jugadas: ");
                                fila[5] = sc.nextLine();
                                break;
                            case 6:
                                System.out.print("¿Es favorito? (true/false): ");
                                fila[6] = sc.nextLine();
                                break;
                            case 7:
                                seguirEditando = false;
                                break;
                            default:
                                System.out.println("Opción no válida.");
                        }
                    }
                    break;
                }
            }

            if (!encontrado) {
                System.out.println("No se encontró un videojuego con ese ID.");
                return;
            }


            try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
                if (header != null) {
                    bw.write(header);
                    bw.newLine();
                }
                for (String[] fila : datos) {
                    bw.write(String.join(",", fila));
                    bw.newLine();
                }
                System.out.println("CSV actualizado correctamente.");
            } catch (IOException e) {
                System.out.println("Error al guardar los cambios: " + e.getMessage());
            }
        }

            public static void DeleteVideogame(int idUser) {
            Scanner sc = new Scanner(System.in);
            String ruta = "C:\\" + idUser + "\\VideoGames.csv";

            List<String[]> datos = new ArrayList<>();

            try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
                String linea;
                while ((linea = br.readLine()) != null) {
                    datos.add(linea.split(","));
                }
            } catch (IOException e) {
                throw new PersistenceException("Error al leer el videojuego con el id:" + idUser);
            }

            System.out.print("Introduce el ID del juego a eliminar: ");
            String idEliminar = sc.nextLine();

            boolean encontrado = false;
            Iterator<String[]> iter = datos.iterator();

            while (iter.hasNext()) {
                String[] fila = iter.next();
                if (fila[0].equals(idEliminar)) {
                    iter.remove();
                    encontrado = true;
                    System.out.println("Juego con ID " + idEliminar + " eliminado.");
                    break;
                }
            }

            if (!encontrado) {
                System.out.println("No se encontró un juego con ese ID.");
            } else {
                try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
                    for (String[] fila : datos) {
                        bw.write(String.join(",", fila));
                        bw.newLine();
                    }
                    System.out.println("CSV actualizado correctamente");
                } catch (IOException e) {
                    throw new PersistenceException("No se ha podido actualizar el CSV");
                }
            }
        }

        public static void Backup(int idUser) {
            File file = new File("C:\\" + idUser + "\\VideoGames.csv");
            File destinationFile = new File("C:\\" + idUser + "\\Backup" + idUser + ".csv");

            try {
                Files.copy(file.toPath(), destinationFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                System.out.print("Backup completado");
            } catch (IOException e) {
                throw new PersistenceException("Error al realizar el backup del usuario:" + idUser);
            }
        }

        public static void ExportFile(int idUser) {
            File file = new File("C:\\" + idUser + "\\VideoGames.csv");
            File destinationFile = new File("C:\\" + idUser + ".csv");

            try {
                Files.copy(file.toPath(), destinationFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                System.out.print("Archivo exportado correctamente");
            } catch (IOException e) {
                throw new PersistenceException("Error al exportar el archivo del usuario:" + idUser);
            }

        }

        public static void ImportFile(int idUser) {
            Scanner sc = new Scanner(System.in);

            System.out.print("Escribe la ruta del archivo: ");
            String filePath = sc.nextLine();

            try {
                FileWriter editor = new FileWriter("C:\\" + idUser + "\\VideoGames.csv", true);

                File fileImported = new File(filePath);
                Scanner reader = new Scanner(fileImported);

                while (reader.hasNextLine()) {
                    String line = reader.nextLine();
                    editor.write(line + System.lineSeparator());
                }
                reader.close();
                editor.close();

                System.out.println("Archivo importado correctamente.");

            } catch (IOException e) {
                throw new PersistenceException("Error al importar el archivo con el usuario: " + idUser);
            }
        }

        public static void ConsultFile(int idUser) {
            File f = new File("C:\\" + idUser + "\\VideoGames.csv");
            try {
                Scanner reader = new Scanner(f);
                while (reader.hasNextLine()) {
                    String line = reader.nextLine();
                    System.out.println(line);
                }
                reader.close();

            } catch (IOException e) {
                throw new PersistenceException("Error al leer el archivo del usuario: " + idUser);
            }
        }

        public static void searchVideogame(int idUser) {
            Scanner sc = new Scanner(System.in);
            File archivo = new File("C:\\" + idUser + "\\VideoGames.csv");
            boolean finded = false;

            System.out.print("Introduce el nombre del videojuego o el id: ");
            String searching = sc.nextLine();


            try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
                String linea;
                while ((linea = br.readLine()) != null) {
                    String[] columnas = linea.split(",");

                    if (columnas[0].equalsIgnoreCase("identificador")) continue;

                    if (columnas[0].equals(searching) || columnas[1].equalsIgnoreCase(searching)) {
                        System.out.println("Videojuego encontrado:");
                        System.out.println(Arrays.toString(columnas));
                        finded = true;
                        break;
                    }
                }
            } catch (IOException e) {

                e.printStackTrace();
            }
        }
    }
}