
import java.io.File;
import java.util.*;

public class ProyectoPrincipal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean salir = true;

        final int IDUSER = User.idUser();

        while (salir) {

            System.out.println("===== MENÚ PRINCIPAL =====");
            System.out.println("1. Crear videojuego");
            System.out.println("2. Eliminar videojuego");
            System.out.println("3. Editar videojuego");
            System.out.println("4. Consultar todos los videojuegos");
            System.out.println("5. Buscar videojuego por ID o título");
            System.out.println("6. Exportar archivo");
            System.out.println("7. Importar archivo");
            System.out.println("8. Hacer backup del archivo");
            System.out.println("9. Salir");
            System.out.print("> ");

            String opcion = sc.nextLine();

            switch (opcion) {
                case "1":
                    Clases.FileSystem.CreateVideogame(IDUSER);
                    break;
                case "2":
                    Clases.FileSystem.DeleteVideogame(IDUSER);
                    break;
                case "3":
                    Clases.FileSystem.EditFile(IDUSER);
                    break;
                case "4":
                    Clases.FileSystem.ConsultFile(IDUSER);
                    break;
                case "5":
                    Clases.FileSystem.searchVideogame(IDUSER);
                    break;
                case "6":
                    Clases.FileSystem.ExportFile(IDUSER);
                    break;
                case "7":
                    Clases.FileSystem.ImportFile(IDUSER);
                    break;
                case "8":
                    Clases.FileSystem.Backup(IDUSER);
                    break;
                case "9":
                    salir = false;
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción no válida, inténtalo de nuevo.");
            }
    }
}

class User {
    public static int idUser(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce tu id para iniciar sesión: ");
        System.out.print("> ");

        int idUser = sc.nextInt();
        User.logIn(idUser);
        final int IDUSER = idUser;
        return IDUSER;
    }

    public static void logIn(int idUser) {
        Scanner sc = new Scanner(System.in);

        String basePath = "C:\\";

        File userDirectory = new File(basePath + idUser);

        if (userDirectory.exists() && userDirectory.isDirectory()) {
            System.out.println("Bienvenido de nuevo, usuario " + idUser);

            String[] archivos = userDirectory.list();

            if (archivos != null && archivos.length > 0) {
                System.out.println("Tus archivos:");
                for (String nombre : archivos) {
                    System.out.println(" - " + nombre);
                }
            } else {
                System.out.println("No tienes archivos en tu carpeta todavía.");
            }

        } else {
            System.out.println("El usuario con id " + idUser + " no existe.");
            System.out.print("¿Quieres crear un nuevo usuario? (s/n): ");
            String respuesta = sc.nextLine();

            if (respuesta.equalsIgnoreCase("s")) {
                if (userDirectory.mkdir()) {
                    System.out.println("Usuario creado con éxito en " + userDirectory.getAbsolutePath());
                } else {
                    System.out.println("No se pudo crear el usuario.");
                }
            } else {
                System.out.println("Operación cancelada.");
            }
        }
    }
}

class VideoGame {
    int id;
    String title;
    String genre;
    String company;
    Date releaseDate;
    int hoursPlayed;
    boolean favourite;

    public VideoGame(int id, String title, String genre, String company, Date releaseDate, int hoursPlayed, boolean favourite) {
        this.id = id;
        this.title = title;
        this.genre = genre;
        this.company = company;
        this.releaseDate = releaseDate;
        this.hoursPlayed = hoursPlayed;
        this.favourite = favourite;
    }
}
}